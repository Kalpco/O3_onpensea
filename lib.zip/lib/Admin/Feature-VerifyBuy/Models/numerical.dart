class Numerical {
  String numerical;
  bool isSelected = false;

  Numerical(this.numerical, this.isSelected);
}
