class ApiUrl {
  static String API_URL_BUYER = "http://13.200.230.114:11005/";
  static String API_URL_SELLER = "http://13.200.230.114:11006/";
  static String API_URL_PROPERTY = "http://13.200.230.114:11003/";
  static String API_URL_TOKEN = "http://13.200.230.114:11007/";
  static String API_URL_USERMANAGEMENT = "http://13.200.230.114:11000/";
  static String API_URL_GETTOKENPRICE = "http://13.200.230.114:11100/";

// static String API_URL_BUYER = "http://10.0.2.2:11005/";
// static String API_URL_SELLER = "http://10.0.2.2:11006/";
//
// static String API_URL_TOKEN = "http://10.0.2.2:11007/";
//   static String API_URL_USERMANAGEMENT = "http://10.0.2.2:11000/";

//static String API_URL_PROPERTY = "http://10.0.2.2:11003/";
}
