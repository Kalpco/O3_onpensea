class UserType {

  static String ADMIN_USER = "ADMIN";
  static String USER_USER = "USER";

}