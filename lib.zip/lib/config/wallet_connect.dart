class WalletConnect {
  static const projectId = "fcf9f457c1c6ef3dba61870b3fb3cb4b";
}