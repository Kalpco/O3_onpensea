class TestScreen {
  void test() {
    print("hello");
    print("hello 2");
  }
}
